<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<?php if ($__env->exists('painel.layouts.head')) echo $__env->make('painel.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>

  <!-- ======= Header ======= -->
  <?php if ($__env->exists('painel.layouts.header')) echo $__env->make('painel.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- ======= Sidebar ======= -->
  <?php if ($__env->exists('painel.layouts.sidebar')) echo $__env->make('painel.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- ======= Content ======= -->
  <?php echo $__env->yieldContent('content'); ?>

  <!-- ======= Footer ======= -->
  <?php if ($__env->exists('painel.layouts.footer')) echo $__env->make('painel.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH E:\wamp64\www\work\NiceAdmin-template-laravel\resources\views/painel/layouts/base.blade.php ENDPATH**/ ?>